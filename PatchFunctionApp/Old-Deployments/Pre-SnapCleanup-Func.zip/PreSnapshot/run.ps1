param($eventGridEvent, $TriggerMetadata)

Import-Module Az.Accounts
Import-Module Az.Compute
Import-Module Az.Resources

Write-Host "PreSnapshot VERSION 2025-08-29-2204 (idempotent)"

Connect-AzAccount -Identity | Out-Null

# ---------- Read Maintenance Configuration and tags ----------
$data = $eventGridEvent.data
$mcId = $data.MaintenanceConfigurationId
if ([string]::IsNullOrWhiteSpace($mcId)) {
    Write-Warning "No MaintenanceConfigurationId in event; aborting."
    return
}

# Switch to MC subscription
$mcParts = $mcId -split '/'
$subId = $mcParts[2]
Select-AzSubscription -SubscriptionId $subId | Out-Null

$mc   = Get-AzResource -ResourceId $mcId -ErrorAction Stop
$tags = $mc.Tags; if (-not $tags) { $tags = @{} }

# Selection keys from MC tags (match VM tags)
$groupVal    = $tags.ContainsKey('Group')    ? $tags['Group']    : $null
$scheduleVal = $tags.ContainsKey('Schedule') ? $tags['Schedule'] : $null
if ([string]::IsNullOrWhiteSpace($groupVal) -and [string]::IsNullOrWhiteSpace($scheduleVal)) {
    Write-Warning "MC has no Group/Schedule tags; nothing to select."
    return
}

# Optional controls
$retain = 24
if ($tags.ContainsKey('Snapshot.RetainHours')) { $tmp=0; if ([int]::TryParse($tags['Snapshot.RetainHours'],[ref]$tmp)){$retain=$tmp} }
$limit  = 200
if ($tags.ContainsKey('Snapshot.Max')) { $tmp2=0; if ([int]::TryParse($tags['Snapshot.Max'],[ref]$tmp2)){$limit=$tmp2} }
$rgList = @()
if ($tags.ContainsKey('Snapshot.RGs')) { $rgList = ($tags['Snapshot.RGs'] -split ',') | % { $_.Trim() } | ? { $_ } }

function Parse-DiskArmId {
    param([Parameter(Mandatory)][string]$Id)
    $p = $Id -split '/'
    [pscustomobject]@{ SubscriptionId=$p[2]; ResourceGroup=$p[4]; Name=$p[-1] }
}

function New-DeterministicName {
    param([string]$VmName,[string]$DiskKind,[string]$DiskName,[string]$EventId)
    $suffix = ($EventId -replace '[^a-zA-Z0-9]','')
    if ($suffix.Length -gt 12) { $suffix = $suffix.Substring(0,12) }
    $name = ("{0}-{1}-{2}-{3}" -f $VmName, $DiskKind.ToLower(), $DiskName, $suffix)
    if ($name.Length -gt 80) { $name = $name.Substring(0,80) }
    return $name
}

function Ensure-Tags {
    param([string]$ResourceId,[hashtable]$Tags)
    try { Update-AzTag -ResourceId $ResourceId -Tag $Tags -Operation Merge | Out-Null }
    catch { try { Set-AzResource -ResourceId $ResourceId -Tag $Tags -Force | Out-Null } catch {} }
}

function New-DiskSnapshot {
    param(
        [Parameter(Mandatory)][string]$DiskResourceId,
        [Parameter(Mandatory)][string]$SnapshotRG,
        [Parameter(Mandatory)][string]$VmName,
        [Parameter(Mandatory)][string]$DiskName,
        [Parameter(Mandatory)][string]$DiskKind,
        [Parameter(Mandatory)][int]$RetainHours,
        [Parameter(Mandatory)][string]$MaintenanceConfigId,
        [Parameter(Mandatory)][string]$EventId,
        [Parameter()][string]$GroupValue,
        [Parameter()][string]$ScheduleValue
    )

    $meta = Parse-DiskArmId -Id $DiskResourceId
    try { $disk = Get-AzDisk -ResourceGroupName $meta.ResourceGroup -DiskName $meta.Name -ErrorAction Stop }
    catch { Write-Warning ("Get-AzDisk failed for {0}: {1}" -f $DiskResourceId, $_.Exception.Message); return [pscustomobject]@{Status='Failed'} }

    $snapName = New-DeterministicName -VmName $VmName -DiskKind $DiskKind -DiskName $DiskName -EventId $EventId

    $existing = Get-AzSnapshot -ResourceGroupName $SnapshotRG -SnapshotName $snapName -ErrorAction SilentlyContinue
    if ($existing) {
        $expires = (Get-Date).ToUniversalTime().AddHours($RetainHours).ToString('o')
        $tagsToSet = @{
            Purpose='PrePatch'; VMName=$VmName; DiskName=$DiskName; DiskKind=$DiskKind;
            ExpireOnUtc=$expires; CreatedBy='UpdateManager-EventGrid';
            MaintenanceConfigurationId=$MaintenanceConfigId; EventId=$EventId
        }
        if ($GroupValue)    { $tagsToSet['Group']=$GroupValue }
        if ($ScheduleValue) { $tagsToSet['Schedule']=$ScheduleValue }
        Ensure-Tags -ResourceId $existing.Id -Tags $tagsToSet
        Write-Host ("Duplicate detected -> skipping {0}" -f $snapName)
        return [pscustomobject]@{Status='Skipped'}
    }

    $expires = (Get-Date).ToUniversalTime().AddHours($RetainHours).ToString('o')
    $cfg = New-AzSnapshotConfig -Location $disk.Location -CreateOption Copy -SourceUri $disk.Id -Incremental

    try { $snap = New-AzSnapshot -ResourceGroupName $SnapshotRG -SnapshotName $snapName -Snapshot $cfg }
    catch {
        if ($_.Exception.Message -match 'already exists|Conflict') {
            return [pscustomobject]@{Status='Skipped'}
        }
        Write-Warning ("New-AzSnapshot failed: {0}" -f $_.Exception.Message)
        return [pscustomobject]@{Status='Failed'}
    }

    $sTags = @{
        Purpose='PrePatch'; VMName=$VmName; DiskName=$DiskName; DiskKind=$DiskKind;
        ExpireOnUtc=$expires; CreatedBy='UpdateManager-EventGrid';
        MaintenanceConfigurationId=$MaintenanceConfigId; EventId=$EventId
    }
    if ($GroupValue)    { $sTags['Group']=$GroupValue }
    if ($ScheduleValue) { $sTags['Schedule']=$ScheduleValue }

    Ensure-Tags -ResourceId $snap.Id -Tags $sTags

    Write-Host ("Snapshot {0} created" -f $snapName)
    return [pscustomobject]@{Status='Created'}
}

function New-PrePatchSnapshots-ForVM {
    param(
        [Parameter(Mandatory)][Microsoft.Azure.Commands.Compute.Models.PSVirtualMachine]$VM,
        [Parameter(Mandatory)][int]$RetainHours,
        [Parameter(Mandatory)][string]$MaintenanceConfigId,
        [Parameter(Mandatory)][string]$EventId,
        [Parameter()][string]$GroupValue,
        [Parameter()][string]$ScheduleValue
    )

    $rg = $VM.ResourceGroupName
    $created = 0; $skipped = 0; $failed = 0

    $os = $VM.StorageProfile.OsDisk
    $isEphemeral = ($os.DiffDiskSettings -and $os.DiffDiskSettings.Option -eq 'Local')

    if (-not $isEphemeral) {
        $osId = $os.ManagedDisk.Id
        $res = New-DiskSnapshot -DiskResourceId $osId -SnapshotRG $rg -VmName $VM.Name -DiskName $os.Name -DiskKind 'OS' -RetainHours $RetainHours -MaintenanceConfigId $MaintenanceConfigId -EventId $EventId -GroupValue $GroupValue -ScheduleValue $ScheduleValue
        switch ($res.Status) { 'Created'{$created++} 'Skipped'{$skipped++} default{$failed++} }
    }

    foreach ($d in $VM.StorageProfile.DataDisks) {
        $ddId = $d.ManagedDisk.Id
        $res = New-DiskSnapshot -DiskResourceId $ddId -SnapshotRG $rg -VmName $VM.Name -DiskName $d.Name -DiskKind 'Data' -RetainHours $RetainHours -MaintenanceConfigId $MaintenanceConfigId -EventId $EventId -GroupValue $GroupValue -ScheduleValue $ScheduleValue
        switch ($res.Status) { 'Created'{$created++} 'Skipped'{$skipped++} default{$failed++} }
    }

    [pscustomobject]@{Created=$created;Skipped=$skipped;Failed=$failed}
}

# ---------- Find target VMs ----------
$vms = Get-AzVM -Status
if ($groupVal)    { $vms = $vms | ? { $_.Tags['Group'] -eq $groupVal } }
if ($scheduleVal) { $vms = $vms | ? { $_.Tags['Schedule'] -eq $scheduleVal } }

$vms = $vms | Sort-Object Id -Unique | Select-Object -First $limit

$globalCreated=0; $globalSkipped=0; $globalFailed=0
foreach ($vm in $vms) {
    $res = New-PrePatchSnapshots-ForVM -VM $vm -RetainHours $retain -MaintenanceConfigId $mcId -EventId $eventGridEvent.id -GroupValue $groupVal -ScheduleValue $scheduleVal
    $globalCreated += $res.Created
    $globalSkipped += $res.Skipped
    $globalFailed  += $res.Failed
}

Write-Host ("Summary: created={0}, skipped={1}, failed={2}" -f $globalCreated,$globalSkipped,$globalFailed)
