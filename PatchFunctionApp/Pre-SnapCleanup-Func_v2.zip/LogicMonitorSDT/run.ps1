param($eventGridEvent, $TriggerMetadata)

Write-Host "LogicMonitorSDT starting..."

# ================
# Read env vars
# ================
$lmAuth      = $env:lm_auth         # Expected format: "<accessId>:<accessKey>"
$lmCompany   = $env:lm_company      # e.g. "tieva"
$lmDomain    = $env:lm_domain_name  # e.g. "logicmonitor.com" or "logicmonitor.eu"
$tenantId    = $env:LM_tenant_id    # For logging only (multi-tenant context)
$durationStr = $env:LM_sdt_minutes  # OPTIONAL, if you later add it. Otherwise we default.

if (-not $lmCompany) { throw "Env var 'lm_company' is not set." }
if (-not $lmAuth)    { throw "Env var 'lm_auth' is not set (expected '<accessId>:<accessKey>')." }

if (-not $lmDomain -or $lmDomain.Trim() -eq "") {
    $lmDomain = "logicmonitor.com"
}

$durationMinutes = 0
if (-not [int]::TryParse($durationStr, [ref]$durationMinutes) -or $durationMinutes -le 0) {
    $durationMinutes = 120   # default: 2 hours
}

$baseUri = "https://$lmCompany.$lmDomain/santaba/rest"

Write-Host "Using LogicMonitor base URI: $baseUri"
Write-Host "SDT duration (minutes): $durationMinutes"

# ================
# Filter event type
# ================
$eventType = $eventGridEvent.eventType
Write-Host "EventType: $eventType"

if ($eventType -and $eventType -notlike "*PreMaintenanceEvent*") {
    Write-Host "Not a Pre-Maintenance event. Exiting without creating SDT."
    return
}

$maintenanceRunId      = $eventGridEvent.data.CorrelationId
$maintenanceConfigId   = $eventGridEvent.data.MaintenanceConfigurationId

Write-Host "Pre-Maintenance event detected."
Write-Host "MaintenanceRunId: $maintenanceRunId"
Write-Host "MaintenanceConfigurationId: $maintenanceConfigId"
Write-Host "TenantId (LM_tenant_id): $tenantId"

# ================
# Time window
# ================
$nowUtc     = [DateTimeOffset]::UtcNow
$startEpoch = $nowUtc.ToUnixTimeMilliseconds()
$endEpoch   = $nowUtc.AddMinutes($durationMinutes).ToUnixTimeMilliseconds()

Write-Host ("Creating SDT from {0} for {1} minutes" -f $nowUtc.ToString("u"), $durationMinutes)

# TODO: Set this to the actual group in LogicMonitor you want to SDT
# Example: Azure\Prod\PatchWindow1 -> "Azure\\Prod\\PatchWindow1"
$deviceGroupFullPath = "Azure\\YOUR\\GROUP\\PATH"

# ================
# LMv1 auth pieces
# ================
$lmParts = $lmAuth.Split(":", 2)
if ($lmParts.Count -lt 2) {
    throw "Env var 'lm_auth' must be in the format '<accessId>:<accessKey>'."
}

$accessId  = $lmParts[0]
$accessKey = $lmParts[1]

$resourcePath = "/sdt/sdts"
$httpVerb     = "POST"

$bodyObj = @{
    sdtType             = 1  # 1 = one-time
    type                = "DeviceGroupSDT"
    deviceGroupFullPath = $deviceGroupFullPath
    dataSourceId        = 0  # 0 = all datasources
    comment             = "Azure Update Manager Pre-Maintenance run $maintenanceRunId (tenant $tenantId)"
    startDateTime       = [int64]$startEpoch
    endDateTime         = [int64]$endEpoch
}

$bodyJson = $bodyObj | ConvertTo-Json -Depth 10 -Compress

# epoch in ms (string)
$epoch = [string]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())

# String to sign per LM docs: httpVerb + epoch + data + resourcePath
$requestVars = $httpVerb + $epoch + $bodyJson + $resourcePath

$encoding = [System.Text.Encoding]::UTF8
$hmac     = New-Object System.Security.Cryptography.HMACSHA256
$hmac.Key = $encoding.GetBytes($accessKey)

$hashBytes = $hmac.ComputeHash($encoding.GetBytes($requestVars))
# hex string:
$hashHex   = -join ($hashBytes | ForEach-Object { $_.ToString("x2") })
# base64 of hex:
$signature = [Convert]::ToBase64String($encoding.GetBytes($hashHex))

$authHeader = "LMv1 $accessId:$signature:$epoch"

# ================
# Call LogicMonitor
# ================
$uri = "$baseUri$resourcePath"

$headers = @{
    "Authorization" = $authHeader
    "Content-Type"  = "application/json"
}

Write-Host "Posting SDT to LogicMonitor: $uri"
Write-Host "Device Group: $deviceGroupFullPath"

try {
    $response = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body $bodyJson -ErrorAction Stop
    Write-Host "LogicMonitor SDT created successfully."
    Write-Host ($response | ConvertTo-Json -Depth 6)
}
catch {
    Write-Error "Failed to create LogicMonitor SDT: $($_.Exception.Message)"
    throw
}
